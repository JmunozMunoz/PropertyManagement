﻿using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using Property.Core.Entities;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Repositories;
using System.Text;
using System.Threading.Tasks;

namespace Property.UnitTest
{
    public class UTestPropertyImage
    {

        private readonly DbContextOptionsBuilder<PropertyContext> optionsBuilder = new DbContextOptionsBuilder<PropertyContext>();
        private readonly PropertyContext context = new PropertyContext();
        private readonly UnitOfWork unitOfWork = new(new PropertyContext());
        private readonly PropertyImageService propertyImageService = new PropertyImageService(new UnitOfWork(new PropertyContext()));

        public UTestPropertyImage()
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=PropertyDB;Integrated Security=True");

            context = new(optionsBuilder.Options);

            unitOfWork = new(context);

            propertyImageService = new(unitOfWork);
        }

        [Test]
        public async Task InsertPropertyImageAsync_WithNewValue_ReturnIsInstanceOf()
        {
            PropertyImage propertyImage = new();

            propertyImage.IdProperty = 4;
            propertyImage.File = Encoding.ASCII.GetBytes("0xD31DF4EFCE3AE3AE38DFCE3AE3AE39DF4DF4");
            propertyImage.Enabled = 1;

            await propertyImageService.InsertPropertyImage(propertyImage);

            Assert.IsInstanceOf<PropertyImage>(propertyImage);
        }
    }
}
