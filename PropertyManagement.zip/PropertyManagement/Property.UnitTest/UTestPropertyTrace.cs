﻿using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using Property.Core.Entities;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Repositories;
using System.Threading.Tasks;

namespace Property.UnitTest
{
    public class UTestPropertyTrace
    {
        private readonly DbContextOptionsBuilder<PropertyContext> optionsBuilder = new DbContextOptionsBuilder<PropertyContext>();
        private readonly PropertyContext context = new PropertyContext();
        private readonly UnitOfWork unitOfWork = new(new PropertyContext());
        private readonly PropertyTraceService propertyTraceService = new PropertyTraceService(new UnitOfWork(new PropertyContext()));

        public UTestPropertyTrace()
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=PropertyDB;Integrated Security=True");

            context = new(optionsBuilder.Options);

            unitOfWork = new(context);

            propertyTraceService = new(unitOfWork);
        }

        [Test]
        public async Task ChangePriceAsync_WithNewValue_ReturnIsInstanceOf()
        {
            PropertyTrace propertyTrace = new();

            propertyTrace.IdProperty = 3;
            propertyTrace.Name = "Test Unit";
            propertyTrace.Tax = 9008;
            propertyTrace.Value = 980000001;

            //Create the Property Trace with a new price
            await propertyTraceService.ChangePrice(propertyTrace);

            Assert.IsInstanceOf<PropertyTrace>(propertyTrace);
        }
    }
}
