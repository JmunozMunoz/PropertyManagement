﻿using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using Property.Core.Entities;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Repositories;
using System.Threading.Tasks;


namespace Property.UnitTest
{
    public class UTestSecurity
    {
        private readonly DbContextOptionsBuilder<PropertyContext> optionsBuilder = new DbContextOptionsBuilder<PropertyContext>();
        private readonly PropertyContext context = new PropertyContext();
        private readonly UnitOfWork unitOfWork = new(new PropertyContext());
        private readonly SecurityService securityServiceProvider = new SecurityService(new UnitOfWork(new PropertyContext()));

        public UTestSecurity()
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=PropertyDB;Integrated Security=True");

            context = new(optionsBuilder.Options);

            unitOfWork = new(context);

            securityServiceProvider = new(unitOfWork);
        }

        [Test]
        public async Task RegisterUserAsync_NewUser_ReturnIsInstanceOf()
        {
            Security security = new();
            security.User = "unittest";
            security.Password = "unittest";
            security.UserName = "Unit Test Exit";
            security.Role = Core.Enumerations.RoleType.Consumer;

            await securityServiceProvider.RegisterUser(security);

            Assert.IsInstanceOf<Security>(security);
        }
    }
}

