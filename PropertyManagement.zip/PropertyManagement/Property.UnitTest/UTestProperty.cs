﻿using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using Property.Core.Entities;
using Property.Core.QueryFilters;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace Property.UnitTest
{
    public class UTestProperty
    {
        private readonly DbContextOptionsBuilder<PropertyContext> optionsBuilder = new DbContextOptionsBuilder<PropertyContext>();
        private readonly PropertyContext context = new PropertyContext();
        private readonly UnitOfWork unitOfWork = new(new PropertyContext());
        private readonly PropertyService propertyService = new PropertyService(new UnitOfWork(new PropertyContext()));

        public UTestProperty()
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=PropertyDB;Integrated Security=True");

            context = new(optionsBuilder.Options);

            unitOfWork = new(context);

            propertyService = new(unitOfWork);
        }

        [Test]
        public async Task GetPropertiesAsync_WithoutFilters_ReturnEquals()
        {
            PropertyQueryFilter filters = new();

            List<Core.Entities.Property>? properties = await propertyService.GetProperties(filters);

            Assert.AreEqual(3, properties.Count);
        }

        [Test]
        public async Task UpdatePropertyAsync_ChangeCodeInternal_ReturnEquals()
        {
            Core.Entities.Property property = new();

            property.Id = 4;
            property.CodeInternal = "UTest_001";

            var result = await propertyService.UpdateProperty(property);

            Assert.AreEqual("TRUE", result.ToString().ToUpper());
        }
    }
}
