﻿using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using Property.Core.Entities;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Repositories;
using System.Threading.Tasks;

namespace Property.UnitTest
{
    public class UTestToken
    {
        private readonly DbContextOptionsBuilder<PropertyContext> optionsBuilder = new DbContextOptionsBuilder<PropertyContext>();
        private readonly PropertyContext context = new PropertyContext();
        private readonly UnitOfWork unitOfWork = new(new PropertyContext());
        private readonly SecurityService serviceProvider = new SecurityService(new UnitOfWork(new PropertyContext()));

        public UTestToken()
        {
            optionsBuilder.UseSqlServer("Data Source=localhost;Initial Catalog=PropertyDB;Integrated Security=True");

            context = new(optionsBuilder.Options);

            unitOfWork = new(context);

            serviceProvider = new(unitOfWork);
        }   
        
        [Test]
        public async Task GetLoginByCredentialsAsync_WithExistUserLogin_ReturnNotNull()
        {
            UserLogin userLogin = new();
            userLogin.User = "Admin";
            userLogin.Password = "Admin";

            var user = await serviceProvider.GetLoginByCredentials(userLogin);
            
            Assert.IsNotNull(user, "Credentials Exists");
        }

        [Test]
        public async Task GetLoginByCredentialsAsync_WithUnExistUserLogin_ReturnNull()
        {
            UserLogin userLogin = new();
            userLogin.User = "Admin1";
            userLogin.Password = "Admin1";

            var user = await serviceProvider.GetLoginByCredentials(userLogin);

            Assert.IsNull(user, "Credentials Exists");
        }
    }
}
