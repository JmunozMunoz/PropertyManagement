﻿namespace Property.Core.DTOs
{
    /// <summary>
    /// Entity Property Image Data Transfer Object
    /// </summary>
    public class PropertyImageDto
    {
        /// <summary>
        /// Property ID
        /// </summary>
        public int? IdProperty { get; set; }
        /// <summary>
        /// Image
        /// </summary>
        public byte[] File { get; set; }
        /// <summary>
        /// Enabled Image
        /// </summary>
        public int Enabled { get; set; }
    }
}
