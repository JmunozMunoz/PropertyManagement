﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Property.Core.DTOs
{
    public class PropertyTraceDto
    {
        /// <summary>
        /// Id Property
        /// </summary>
        public int IdProperty { get; set; }
        /// <summary>
        /// Property Value
        /// </summary>
        public long Value { get; set; }
        /// <summary>
        /// Property Trace Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Tax
        /// </summary>
        public decimal Tax { get; set; }
        /// <summary>
        /// Date Sale
        /// </summary>
        public DateTime DateSale { get; set; }
    }
}
