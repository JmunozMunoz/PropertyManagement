﻿using Property.Core.Enumerations;

namespace Property.Core.DTOs
{
    /// <summary>
    /// Entity Security Data Transfer Object
    /// </summary>
    public class SecurityDto
    {
        /// <summary>
        /// User Security
        /// </summary>
        public string User { get; set; }
        /// <summary>
        /// Name Security
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Password Security
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Role Security
        /// </summary>
        public RoleType? Role { get; set; }
    }
}
