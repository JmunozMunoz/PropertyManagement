﻿
using Property.Core.Entities;
using System.Collections.Generic;

namespace Property.Core.DTOs
{
    /// <summary>
    /// Entity Property Data Transfer Object
    /// </summary>
    public class PropertyDetailDto
    {
        /// <summary>
        /// Property ID
        /// </summary>
        public int? IdProperty { get; set; }
        /// <summary>
        /// Property Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Address
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Property Price
        /// </summary>
        public long? Price { get; set; }
        /// <summary>
        /// Code Internal
        /// </summary>
        public string CodeInternal { get; set; }
        /// <summary>
        /// Property Year
        /// </summary>
        public int? Year { get; set; }
        /// <summary>
        /// Owner
        /// </summary>
        public virtual Owner IdOwnerNavigation { get; set; }
        /// <summary>
        /// PropertyImages
        /// </summary>
        public virtual ICollection<PropertyImage> PropertyImages { get; set; }
        /// <summary>
        /// Property Trace
        /// </summary>
        public virtual ICollection<PropertyTrace> PropertyTraces { get; set; }
    }
}
