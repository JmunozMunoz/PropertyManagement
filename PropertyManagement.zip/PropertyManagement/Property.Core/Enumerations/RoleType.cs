﻿namespace Property.Core.Enumerations
{
    /// <summary>
    /// Roles Type
    /// </summary>
    public enum RoleType
    {
        Administrator,
        Consumer
    }
}
