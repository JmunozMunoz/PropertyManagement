﻿using System;

namespace Property.Core.Exceptions
{
    /// <summary>
    /// Management Exceptions to API
    /// </summary>
    public class BusinessException : Exception
    {
        #region Constructors
        public BusinessException()
        {

        }

        public BusinessException(string message) : base(message)
        {

        }
        #endregion
    }
}
