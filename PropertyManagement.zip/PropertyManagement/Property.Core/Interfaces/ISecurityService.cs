﻿using Property.Core.Entities;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Manager Security Services
    /// </summary>
    public interface ISecurityService
    {
        /// <summary>
        /// Get Login by Credencials
        /// </summary>
        /// <param name="userLogin">Login</param>
        /// <returns>Security</returns>
        Task<Security> GetLoginByCredentials(UserLogin userLogin);
        /// <summary>
        /// Register User
        /// </summary>
        /// <param name="security">Security</param>
        /// <returns>Task</returns>
        Task RegisterUser(Security security);
    }
}