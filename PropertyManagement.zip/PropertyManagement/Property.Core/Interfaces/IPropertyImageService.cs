﻿using Property.Core.Entities;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Service Property Images
    /// </summary>
    public interface IPropertyImageService
    {
        /// <summary>
        /// Method Create Property Image
        /// </summary>
        /// <param name="propertyImage">Property Image</param>
        /// <returns></returns>
        Task InsertPropertyImage(PropertyImage propertyImage);
    }
}
