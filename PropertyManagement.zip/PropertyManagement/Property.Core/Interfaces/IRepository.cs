﻿using Property.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Repository
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IRepository<T> where T : BaseEntity
    {
        /// <summary>
        /// Get All Entities
        /// </summary>
        /// <returns>Entities</returns>
        Task<IEnumerable<T>> GetAll();
        /// <summary>
        /// Get Entity by Id
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>Entity</returns>
        Task<T> GetById(int id);
        /// <summary>
        /// Create Record entity
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <returns>Entity</returns>
        Task Add(T entity);
        /// <summary>
        /// Update Record Entity
        /// </summary>
        /// <param name="entity">Entity</param>
        void Update(T entity);
        /// <summary>
        /// Delete Record Entity
        /// </summary>
        /// <param name="id">id</param>
        /// <returns>Entity</returns>
        Task Delete(int id);
    }
}
