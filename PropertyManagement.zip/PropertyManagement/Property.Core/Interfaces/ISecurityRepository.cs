﻿using Property.Core.Entities;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Management Security
    /// </summary>
    public interface ISecurityRepository : IRepository<Security>
    {
        /// <summary>
        /// Get Login by User and Password
        /// </summary>
        /// <param name="login">User and password</param>
        /// <returns>Security</returns>
        Task<Security> GetLoginByCredentials(UserLogin login);
    }
}