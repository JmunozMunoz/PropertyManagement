﻿using Property.Core.Entities;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Service Property Trace
    /// </summary>
    public interface IPropertyTraceService
    {
        /// <summary>
        /// Method Create Property Image
        /// </summary>
        /// <param name="propertyImage">Property Image</param>
        /// <returns></returns>
        Task ChangePrice(PropertyTrace propertyTrace);
    }
}
