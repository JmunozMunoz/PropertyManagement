﻿using Property.Core.QueryFilters;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Service Property
    /// </summary>
    public interface IPropertyService
    {
        /// <summary>
        /// Get Properties by Filters
        /// </summary>
        /// <param name="filters">Filters</param>
        /// <returns>Properties</returns>
        Task<List<Entities.Property>> GetProperties(PropertyQueryFilter filters);

        /// <summary>
        /// Get property by Id
        /// </summary>
        /// <param name="id">Id Property</param>
        /// <returns>Property</returns>
        Task<Entities.Property> GetProperty(int id);

        /// <summary>
        /// Create Ner Property
        /// </summary>
        /// <param name="property">Property</param>
        /// <returns>Property Created</returns>
        Task InsertProperty(Entities.Property property);

        /// <summary>
        /// Update Property Data
        /// </summary>
        /// <param name="property">Property</param>
        /// <returns>Property Updated</returns>
        Task<bool> UpdateProperty(Entities.Property property);

        /// <summary>
        /// Delete Property by Id
        /// </summary>
        /// <param name="id">Id Property</param>
        /// <returns>Property</returns>
        Task<bool> DeleteProperty(int id);
    }
}
