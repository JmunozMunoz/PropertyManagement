﻿using Property.Core.Entities;
using Property.Infrastructure.Repositories;
using System;
using System.Threading.Tasks;

namespace Property.Core.Interfaces
{
    /// <summary>
    /// Interface Manager Unit of Work
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        IPropertyRepository PropertyRepository { get; }

        IRepository<Owner> OwnerRepository { get; }

        IRepository<PropertyTrace> PropertyTraceRepository { get; }

        IRepository<PropertyImage> PropertyImageRepository { get; }

        ISecurityRepository SecurityRepository { get; }

        void SaveChanges();

        Task SaveChangesAsync();
    }
}
