﻿using Property.Core.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Property.Infrastructure.Repositories
{
    /// <summary>
    /// Interface Property Repository Services
    /// </summary>
    public interface IPropertyRepository : IRepository<Property.Core.Entities.Property>
    {
        /// <summary>
        /// Get Properties by Owner
        /// </summary>
        /// <param name="IdOwner">Id Owner</param>
        /// <returns>Properties</returns>
        Task<IEnumerable<Property.Core.Entities.Property>> GetPropertiesByOwner(int IdOwner);
    }
}