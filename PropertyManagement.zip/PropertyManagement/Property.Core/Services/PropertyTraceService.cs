﻿using Property.Core.Entities;
using Property.Core.Exceptions;
using Property.Core.Interfaces;
using System.Threading.Tasks;

namespace Property.Core.Services
{
    public class PropertyTraceService : IPropertyTraceService
    {
        #region Attributes
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region Constructor
        public PropertyTraceService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Method Create Property Trace
        /// </summary>
        /// <param name="propertyImage">Property Image</param>
        /// <returns></returns>
        public async Task ChangePrice(PropertyTrace propertyTrace)
        {
            //Validate Property to asociate
            var property = await _unitOfWork.PropertyRepository.GetById(propertyTrace.IdProperty);

            if (property == null)
            {
                throw new BusinessException("Property doesn't exist");
            }

            //Update Date Now
            propertyTrace.DateSale = System.DateTime.Now;

            //Insert Property trace
            await _unitOfWork.PropertyTraceRepository.Add(propertyTrace);
            await _unitOfWork.SaveChangesAsync();
        }
        public async Task InsertPropertyImage(PropertyImage propertyImage)
        {
            //Validate Property to asociate
            var property = await _unitOfWork.PropertyRepository.GetById(propertyImage.IdProperty);

            if (property == null)
            {
                throw new BusinessException("Property doesn't exist");
            }

            //Insert Property Image
            await _unitOfWork.PropertyImageRepository.Add(propertyImage);
            await _unitOfWork.SaveChangesAsync();
        }
        #endregion
    }
}
