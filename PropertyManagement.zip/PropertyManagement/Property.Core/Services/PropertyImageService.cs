﻿using Property.Core.Entities;
using Property.Core.Exceptions;
using Property.Core.Interfaces;
using System.Threading.Tasks;

namespace Property.Core.Services
{
    public class PropertyImageService : IPropertyImageService
    {

        #region Attributes
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region Constructor
        public PropertyImageService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Method Create Property Image
        /// </summary>
        /// <param name="propertyImage">Property Image</param>
        /// <returns></returns>
        public async Task InsertPropertyImage(PropertyImage propertyImage)
        {
            //Validate Property to asociate
            var property = await _unitOfWork.PropertyRepository.GetById(propertyImage.IdProperty);

            if (property == null)
            {
                throw new BusinessException("Property doesn't exist");
            }

            //Insert Property Image
            await _unitOfWork.PropertyImageRepository.Add(propertyImage);
            await _unitOfWork.SaveChangesAsync();
        }
        #endregion
    }
}
