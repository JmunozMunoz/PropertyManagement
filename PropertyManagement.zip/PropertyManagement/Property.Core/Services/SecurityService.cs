﻿using Property.Core.Entities;
using Property.Core.Interfaces;
using System.Threading.Tasks;

namespace Property.Core.Services
{
    /// <summary>
    /// Manager Security Services
    /// </summary>
    public class SecurityService : ISecurityService
    {
        #region Attributes
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region Constructor
        public SecurityService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get Login by Credencials
        /// </summary>
        /// <param name="userLogin">Login</param>
        /// <returns>Security</returns>
        public async Task<Security> GetLoginByCredentials(UserLogin userLogin)
        {
            return await _unitOfWork.SecurityRepository.GetLoginByCredentials(userLogin);
        }

        /// <summary>
        /// Register User
        /// </summary>
        /// <param name="security">Security</param>
        /// <returns>Task</returns>
        public async Task RegisterUser(Security security)
        {
            await _unitOfWork.SecurityRepository.Add(security);
            await _unitOfWork.SaveChangesAsync();
        }
        #endregion
    }
}