﻿using Property.Core.Exceptions;
using Property.Core.Interfaces;
using Property.Core.QueryFilters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Property.Core.Services
{
    /// <summary>
    /// Service Property Images
    /// </summary>
    public class PropertyService : IPropertyService
    {
        #region MyRegion
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region Constructor
        public PropertyService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Get property by Id
        /// </summary>
        /// <param name="id">Id Property</param>
        /// <returns>Property</returns>
        public async Task<Entities.Property> GetProperty(int id)
        {
            return await _unitOfWork.PropertyRepository.GetById(id);
        }

        /// <summary>
        /// Get Properties by Filters
        /// </summary>
        /// <param name="filters">Filters</param>
        /// <returns>Properties</returns>
        public async Task<List<Entities.Property>> GetProperties(PropertyQueryFilter filters)
        {
            var property = await _unitOfWork.PropertyRepository.GetAll();

            if (filters.IdProperty!= null)
            {
                property = property.Where(x => x.Id == filters.IdProperty);
            }

            if (filters.Name != null)
            {
                //Property are queries by Name
                property = property.Where(x => x.Name.ToLower().Contains(filters.Name.ToLower()));
            }

            if (filters.Address != null)
            {
                //Property are queries by Address
                property = property.Where(x => x.Address.ToLower().Contains(filters.Address.ToLower()));
            }

            if (filters.Price != null)
            {
                //Property are queries by Price
                property = property.Where(x => x.Price <= filters.Price);
            }

            if (filters.CodeInternal != null)
            {
                //Property are queries by Internal Code
                property = property.Where(x => x.CodeInternal.ToLower().Contains(filters.CodeInternal.ToLower()));
            }

            if (filters.Year != null)
            {
                //Property are queries by Year
                property = property.Where(x => x.Year >= filters.Year);
            }

            return property.ToList();
        }

        /// <summary>
        /// Create Ner Property
        /// </summary>
        /// <param name="property">Property</param>
        /// <returns>Property Created</returns>
        public async Task InsertProperty(Entities.Property property)
        {
            //Validate Owner
            var owner = await _unitOfWork.OwnerRepository.GetById(property.IdOwner);

            if (owner == null)
            {
                throw new BusinessException("Owner doesn't exist");
            }

            //Insert Property
            await _unitOfWork.PropertyRepository.Add(property);
            await _unitOfWork.SaveChangesAsync();
        }

        /// <summary>
        /// Update Property Data
        /// </summary>
        /// <param name="property">Property</param>
        /// <returns>Property Updated</returns>
        public async Task<bool> UpdateProperty(Entities.Property property)
        {
            //Validate Owner
            if (property.IdOwner != 0)
            {
                var owner = await _unitOfWork.OwnerRepository.GetById(property.IdOwner);

                if (owner == null)
                {
                    throw new BusinessException("Owner doesn't exist");
                }
            }

            //Update Property
            var existingProperty = await _unitOfWork.PropertyRepository.GetById(property.Id);

            if(existingProperty == null)
            {
                throw new BusinessException("Property to Update doesn't exist");
            }

            if (!String.IsNullOrEmpty(property.Name)) 
                existingProperty.Name = property.Name;
            if (!String.IsNullOrEmpty(property.Address))
                existingProperty.Address = property.Address;
            if (!String.IsNullOrEmpty(property.CodeInternal))
                existingProperty.CodeInternal= property.CodeInternal;
            if (property.Price != 0)
                existingProperty.Price = property.Price;
            if (property.Year != 0)
                existingProperty.Year = property.Year;
            if (property.IdOwner != 0)
                existingProperty.IdOwner = property.IdOwner;

            _unitOfWork.PropertyRepository.Update(existingProperty);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        /// <summary>
        /// Delete Property by Id
        /// </summary>
        /// <param name="id">Id Property</param>
        /// <returns>Property</returns>
        public async Task<bool> DeleteProperty(int id)
        {
            await _unitOfWork.PropertyRepository.Delete(id);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }
        #endregion
    }
}