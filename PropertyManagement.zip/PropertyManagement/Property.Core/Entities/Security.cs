﻿using Property.Core.Enumerations;

namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Security
    /// </summary>
    public class Security : BaseEntity
    {
        /// <summary>
        /// User
        /// </summary>
        public string User { get; set; }
        /// <summary>
        /// User Name
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// Role
        /// </summary>
        public RoleType Role { get; set; }
    }
}
