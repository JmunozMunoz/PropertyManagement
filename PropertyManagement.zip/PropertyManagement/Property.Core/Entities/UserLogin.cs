﻿namespace Property.Core.Entities
{
    /// <summary>
    /// Entity User Login
    /// </summary>
    public class UserLogin
    {
        /// <summary>
        /// User Name
        /// </summary>
        public string User { get; set; }
        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }
    }
}
