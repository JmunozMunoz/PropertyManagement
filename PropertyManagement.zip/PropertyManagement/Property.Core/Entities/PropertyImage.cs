﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Property Image
    /// </summary>
    public partial class PropertyImage : BaseEntity
    {
        /// <summary>
        /// Id Property
        /// </summary>
        public int IdProperty { get; set; }
        /// <summary>
        /// Image
        /// </summary>
        public byte[] File { get; set; }
        /// <summary>
        /// Enabled Image
        /// </summary>
        public int Enabled { get; set; }

        public virtual Property IdPropertyNavigation { get; set; }
    }
}
