﻿namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Base
    /// </summary>
    public abstract class BaseEntity
    {
        /// <summary>
        /// Code Entity Base
        /// </summary>
        public int Id { get; set; }
    }
}
