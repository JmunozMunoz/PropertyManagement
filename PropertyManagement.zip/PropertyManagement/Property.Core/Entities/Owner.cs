﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Owner
    /// </summary>
    public partial class Owner : BaseEntity
    {
        public Owner()
        {
            Properties = new HashSet<Property>();
        }

        /// <summary>
        /// Owner Name 
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Owner Address
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Owner Photo
        /// </summary>
        public byte[] Photo { get; set; }
        /// <summary>
        /// Owner Birthday
        /// </summary>
        public DateTime Birthday { get; set; }

        /// <summary>
        /// Properties
        /// </summary>
        public virtual ICollection<Property> Properties { get; set; }
    }
}
