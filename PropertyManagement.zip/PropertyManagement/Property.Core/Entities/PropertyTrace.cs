﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Property Trace
    /// </summary>
    public partial class PropertyTrace : BaseEntity
    {
        /// <summary>
        /// Date Sale
        /// </summary>
        public DateTime DateSale { get; set; }
        /// <summary>
        /// Property Trace Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Tax
        /// </summary>
        public decimal Tax { get; set; }
        /// <summary>
        /// Id Property
        /// </summary>
        public int IdProperty { get; set; }
        /// <summary>
        /// Property Value
        /// </summary>
        public long Value { get; set; }

        public virtual Property IdPropertyNavigation { get; set; }
    }
}
