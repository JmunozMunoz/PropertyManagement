﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Property.Core.Entities
{
    /// <summary>
    /// Entity Property
    /// </summary>
    public partial class Property : BaseEntity
    {
        #region Constructor
        public Property()
        {
            PropertyImages = new HashSet<PropertyImage>();
            PropertyTraces = new HashSet<PropertyTrace>();
        }
        #endregion

        #region Attributes
        /// <summary>
        /// Property Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Address
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Property Price
        /// </summary>
        public long Price { get; set; }
        /// <summary>
        /// Code Internal
        /// </summary>
        public string CodeInternal { get; set; }
        /// <summary>
        /// Property Year
        /// </summary>
        public int Year { get; set; }
        /// <summary>
        /// Id Owner to Property
        /// </summary>
        public int IdOwner { get; set; }

        public virtual Owner IdOwnerNavigation { get; set; }
        public virtual ICollection<PropertyImage> PropertyImages { get; set; }
        public virtual ICollection<PropertyTrace> PropertyTraces { get; set; }
        #endregion
    }
}
