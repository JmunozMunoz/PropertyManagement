﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Property.Core.QueryFilters
{
    /// <summary>
    /// Entity to Filters Property
    /// </summary>
    public class PropertyQueryFilter
    {
        #region Attributes
        /// <summary>
        /// Property ID
        /// </summary>
        public int? IdProperty { get; set; }
        /// <summary>
        /// Property Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Property Address
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// Property Price
        /// </summary>
        public long? Price { get; set; }
        /// <summary>
        /// Code Internal
        /// </summary>
        public string CodeInternal { get; set; }
        /// <summary>
        /// Property Year
        /// </summary>
        public byte? Year { get; set; }
        /// <summary>
        /// Id Owner to Property
        /// </summary>
        public int? IdOwner { get; set; }

        #endregion
    }
}
