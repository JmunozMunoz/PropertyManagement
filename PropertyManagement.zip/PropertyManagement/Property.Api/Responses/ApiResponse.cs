﻿namespace Property.Api.Responses
{
    /// <summary>
    /// Response API Generic
    /// </summary>
    /// <typeparam name="T">Template</typeparam>
    public class ApiResponse<T>
    {
        public ApiResponse(T data)
        {
            Data = data;
        }

        public T Data { get; set; }
    }
}
