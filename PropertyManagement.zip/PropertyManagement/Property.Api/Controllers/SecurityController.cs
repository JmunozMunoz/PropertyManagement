﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Property.Api.Responses;
using Property.Core.DTOs;
using Property.Core.Entities;
using Property.Core.Enumerations;
using Property.Core.Interfaces;
using Property.Infrastructure.Interfaces;
using System.Threading.Tasks;

namespace Property.Api.Controllers
{
    /// <summary>
    /// Security Controller API
    /// </summary>
    [Authorize(Roles = nameof(RoleType.Administrator))]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class SecurityController : ControllerBase
    {
        #region Attributes

        private readonly ISecurityService _securityService;
        private readonly IMapper _mapper;
        private readonly IPasswordService _passwordService;
        #endregion

        #region Constructor

        public SecurityController(ISecurityService securityService, IMapper mapper, IPasswordService passwordService)
        {
            _securityService = securityService;
            _mapper = mapper;
            _passwordService = passwordService;
        }
        #endregion

        #region Methods APIS
        /// <summary>
        /// API Create User
        /// </summary>
        /// <param name="securityDto"></param>
        /// <returns>User Created</returns>
        [HttpPost]
        public async Task<IActionResult> CreateUser(SecurityDto securityDto)
        {
            var security = _mapper.Map<Security>(securityDto);

            security.Password = _passwordService.Hash(security.Password);
            await _securityService.RegisterUser(security);

            securityDto = _mapper.Map<SecurityDto>(security);
            var response = new ApiResponse<SecurityDto>(securityDto);
            return Ok(response);
        }

        #endregion
    }
}