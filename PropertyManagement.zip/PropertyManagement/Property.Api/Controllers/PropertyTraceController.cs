﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Property.Api.Responses;
using Property.Core.DTOs;
using Property.Core.Entities;
using Property.Core.Interfaces;
using System.Threading.Tasks;

namespace Property.Api.Controllers
{
    /// <summary>
    /// Property Image Controller API
    /// </summary>
    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyTraceController : Controller
    {
        #region Attributes
        private readonly IPropertyTraceService _propertyTraceService;
        private readonly IPropertyService _propertyService;
        private readonly IMapper _mapper;
        #endregion

        #region Constructors
        public PropertyTraceController(IPropertyTraceService propertyTraceService, IPropertyService propertyService, IMapper mapper)
        {
            _propertyTraceService = propertyTraceService;
            _propertyService = propertyService;
            _mapper = mapper;
        }
        #endregion

        /// <summary>
        /// Change Price Property
        /// </summary>
        /// <param name="propertyTraceDto">Property Trace</param>
        /// <returns>Object Property</returns>
        [HttpPost]
        public async Task<IActionResult> ChangePrice(PropertyTraceDto propertyTraceDto)
        {
            var propertyTrace = _mapper.Map<PropertyTrace>(propertyTraceDto);
            
            //Create the Property Trace with a new price
            await _propertyTraceService.ChangePrice(propertyTrace);

            //Update the property with a new price
            Core.Entities.Property property = new Core.Entities.Property();
            property.Id = propertyTrace.IdProperty;
            property.Price = propertyTrace.Value;
            await _propertyService.UpdateProperty(property);

            propertyTraceDto = _mapper.Map<PropertyTraceDto>(propertyTrace);
            var response = new ApiResponse<PropertyTraceDto>(propertyTraceDto);
            return Ok(response);
        }
    }
}
