﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Property.Api.Responses;
using Property.Core.DTOs;
using Property.Core.Entities;
using Property.Core.Interfaces;
using Property.Infrastructure.Interfaces;
using System.Threading.Tasks;

namespace Property.Api.Controllers
{    
    /// <summary>
    /// Property Image Controller API
    /// </summary>
    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyImageController : Controller
    {

        #region Attributes
        private readonly IPropertyImageService _propertyImageService;
        private readonly IMapper _mapper;
        #endregion

        #region Constructors
        public PropertyImageController(IPropertyImageService propertyImageService, IMapper mapper)
        {
            _propertyImageService = propertyImageService;
            _mapper = mapper;
        }
        #endregion

        /// <summary>
        /// Create New Image Property
        /// </summary>
        /// <param name="propertyImageDto">Nwe Property</param>
        /// <returns>Object Property</returns>
        [HttpPost]
        public async Task<IActionResult> InsertImage(PropertyImageDto propertyImageDto)
        {
            var propertyImage = _mapper.Map<PropertyImage>(propertyImageDto);
            await _propertyImageService.InsertPropertyImage(propertyImage);
            propertyImageDto = _mapper.Map<PropertyImageDto>(propertyImage);
            var response = new ApiResponse<PropertyImageDto>(propertyImageDto);
            return Ok(response);
        }
    }
}
