﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Property.Api.Responses;
using Property.Core.DTOs;
using Property.Core.Interfaces;
using Property.Core.QueryFilters;
using Property.Infrastructure.Interfaces;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Property.Api.Controllers
{
    /// <summary>
    /// Property Controller API
    /// </summary>
    [Authorize]
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PropertyController : ControllerBase
    {
        #region Attributes
        private readonly IPropertyService _propertyService;
        private readonly IMapper _mapper;
        #endregion

        #region Constructors
        public PropertyController(IPropertyService propertyService, IMapper mapper)
        {
            _propertyService = propertyService;
            _mapper = mapper;
        }
        #endregion

        #region API
        /// <summary>
        /// Retrieve all Properties
        /// </summary>
        /// <param name="filters">Filters to apply</param>
        /// <returns>Json Properties</returns>
        [HttpGet(Name = nameof(GetProperties))]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(ApiResponse<IEnumerable<PropertyDto>>))]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> GetProperties([FromQuery] PropertyQueryFilter filters)
        {
            var properties = await _propertyService.GetProperties(filters);
            var propertyDetailDto = _mapper.Map<IEnumerable<PropertyDetailDto>>(properties);
            var response = new ApiResponse<IEnumerable<PropertyDetailDto>>(propertyDetailDto);
            return Ok(response);
        }

        /// <summary>
        /// Create New Property
        /// </summary>
        /// <param name="propertyDto">New Property</param>
        /// <returns>Object Property</returns>
        [HttpPost]
        public async Task<IActionResult> InsertProperty(PropertyDto propertyDto)
        {
            var property = _mapper.Map<Core.Entities.Property>(propertyDto);
            await _propertyService.InsertProperty(property);
            propertyDto = _mapper.Map<PropertyDto>(property);
            var response = new ApiResponse<PropertyDto>(propertyDto);
            return Ok(response);
        }

        /// <summary>
        /// Update Property
        /// </summary>
        /// <param name="id">Id Property</param>
        /// <param name="propertyDto">Object Property</param>
        /// <returns>Object updated</returns>
        [HttpPut]
        public async Task<IActionResult> UpdateProperty(int id, PropertyDto propertyDto)
        {
            var property = _mapper.Map<Core.Entities.Property>(propertyDto);
            property.Id = id;
            var result = await _propertyService.UpdateProperty(property);
            var response = new ApiResponse<bool>(result);
            return Ok(response);
        }
        #endregion
    }
}
