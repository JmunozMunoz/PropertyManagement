﻿using Property.Core.Entities;
using Property.Core.Interfaces;
using Property.Infrastructure.Data;
using System.Threading.Tasks;

namespace Property.Infrastructure.Repositories
{
    /// <summary>
    ///  Manager Unit of Work
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        #region Attributes
        private readonly PropertyContext _context;

        private readonly IPropertyRepository _propertyRepository;
        private readonly IRepository<Owner> _ownerRepository;
        private readonly IRepository<PropertyTrace> _propertyTraceRepository;
        private readonly IRepository<PropertyImage> _propertyImageRepository;

        private readonly ISecurityRepository _securityRepository;
        #endregion

        #region Constructor
        public UnitOfWork(PropertyContext context)
        {
            _context = context;
        }
        #endregion

        #region Properties
        public IPropertyRepository PropertyRepository => _propertyRepository ?? new PropertyRepository(_context);

        public IRepository<Owner> OwnerRepository => _ownerRepository ?? new BaseRepository<Owner>(_context);

        public IRepository<PropertyTrace> PropertyTraceRepository => _propertyTraceRepository ?? new BaseRepository<PropertyTrace>(_context);

        public IRepository<PropertyImage> PropertyImageRepository => _propertyImageRepository ?? new BaseRepository<PropertyImage>(_context);

        public ISecurityRepository SecurityRepository => _securityRepository ?? new SecurityRepository(_context);
        #endregion

        #region Methods
        /// <summary>
        /// Dispose BDContext
        /// </summary>
        public void Dispose()
        {
            if (_context != null)
            {
                _context.Dispose();
            }
        }

        /// <summary>
        /// Save Change to BataBase
        /// </summary>
        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        /// <summary>
        /// Save Change to async to DataBase
        /// </summary>
        /// <returns>Task</returns>
        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
        #endregion
    }
}
