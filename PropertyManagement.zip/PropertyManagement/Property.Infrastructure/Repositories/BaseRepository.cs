﻿using Microsoft.EntityFrameworkCore;
using Property.Core.Entities;
using Property.Core.Interfaces;
using Property.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Property.Infrastructure.Repositories
{ 
    /// <summary>
    /// Repository Base Entity
    /// </summary>
    /// <typeparam name="T">Entity Template</typeparam>
    public class BaseRepository<T> : IRepository<T> where T : BaseEntity
    {
        #region Attributes
        private readonly PropertyContext _context;
        protected readonly DbSet<T> _entities;
        #endregion

        #region Constructor
        public BaseRepository(PropertyContext context)
        {
            _context = context;
            _entities = context.Set<T>();
        }
        #endregion

        #region Methods
        /// <summary>
        /// Get All Records Entity
        /// </summary>
        /// <returns>Records</returns>
        public async Task<IEnumerable<T>> GetAll()
        {
            return  _entities.AsEnumerable();
        }

        /// <summary>
        /// Get Record Entity by Id
        /// </summary>
        /// <param name="id">Code</param>
        /// <returns>Record Entity</returns>
        public async Task<T> GetById(int id)
        {
            return await _entities.FindAsync(id);
        }

        /// <summary>
        /// Create Record Entity
        /// </summary>
        /// <param name="entity">Entity</param>
        /// <returns>Task to Entity Created</returns>
        public async Task Add(T entity)
        {
            await _entities.AddAsync(entity);
        }

        /// <summary>
        /// Update Record Entity
        /// </summary>
        /// <param name="entity">Entity</param>
        public void Update(T entity)
        {
            _entities.Update(entity);
        }

        /// <summary>
        /// Delete Record by ID
        /// </summary>
        /// <param name="id">Id Record</param>
        /// <returns>Task entity deleted</returns>
        public async Task Delete(int id)
        {
            T entity = await GetById(id);
            _entities.Remove(entity);
        }
        #endregion
    }
}
