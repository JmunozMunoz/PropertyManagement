﻿using Microsoft.EntityFrameworkCore;
using Property.Core.Entities;
using Property.Core.Interfaces;
using Property.Infrastructure.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Property.Infrastructure.Repositories
{
    /// <summary>
    /// Repository Entity Service
    /// </summary>
    public class PropertyRepository : BaseRepository<Property.Core.Entities.Property>, IPropertyRepository
    {
        #region Constructor
        public PropertyRepository(PropertyContext context) : base(context) { }
        #endregion

        #region Methods
        /// <summary>
        /// Get Properties by Owner
        /// </summary>
        /// <param name="IdOwner">Id Owner</param>
        /// <returns>Task Properties</returns>
        public async Task<IEnumerable<Property.Core.Entities.Property>> GetPropertiesByOwner(int IdOwner)
        {
            return await _entities.Where(x=>x.IdOwner == IdOwner).ToListAsync();
        }
        #endregion

    }
}
