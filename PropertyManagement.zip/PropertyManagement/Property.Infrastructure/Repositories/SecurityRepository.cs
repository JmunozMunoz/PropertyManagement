﻿using Microsoft.EntityFrameworkCore;
using Property.Core.Entities;
using Property.Core.Interfaces;
using Property.Infrastructure.Data;
using System.Threading.Tasks;

namespace Property.Infrastructure.Repositories
{
    /// <summary>
    /// Security Repository Service
    /// </summary>
    public class SecurityRepository : BaseRepository<Security>, ISecurityRepository
    {
        #region Constructor
        public SecurityRepository(PropertyContext context) : base(context) { }
        #endregion

        #region Methods
        /// <summary>
        /// Get Login by Credencials
        /// </summary>
        /// <param name="login">Credencials</param>
        /// <returns>Task Login</returns>
        public async Task<Security> GetLoginByCredentials(UserLogin login)
        {
            return await _entities.FirstOrDefaultAsync(x => x.User == login.User);
        }
        #endregion
    }
}
