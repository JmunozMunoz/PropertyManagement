﻿using AutoMapper;
using Property.Core.DTOs;
using Property.Core.Entities;

namespace Property.Infrastructure.Mappings
{
    /// <summary>
    /// Auto Mapeo
    /// </summary>
    public class AutomapperProfile : Profile
    {
        public AutomapperProfile()
        {
            //Se registra las conversiones que se van a realizar para la Propiedad
            CreateMap<Core.Entities.Property, PropertyDto>();
            CreateMap<PropertyDto, Core.Entities.Property>();

            //Se registra las conversiones que se van a realizar para los detalles de la Propiedad
            CreateMap<Core.Entities.Property, PropertyDetailDto>();
            CreateMap<PropertyDetailDto, Core.Entities.Property>();

            //Se registra las conversiones que se van a realizar para las Imagenes de la Propiedad
            CreateMap<PropertyImage, PropertyImageDto>();
            CreateMap<PropertyImageDto, PropertyImage>();

            //Se registra las conversiones que se van a realizar para las Trazas de la Propiedad
            CreateMap<PropertyTrace, PropertyTraceDto>();
            CreateMap<PropertyTraceDto, PropertyTrace>();

            CreateMap<Security, SecurityDto>().ReverseMap();
        }
    }
}
