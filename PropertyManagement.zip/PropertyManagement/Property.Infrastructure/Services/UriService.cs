﻿using Property.Core.QueryFilters;
using Property.Infrastructure.Interfaces;
using System;

namespace Property.Infrastructure.Services
{
    /// <summary>
    /// Service URI
    /// </summary>
    public class UriService : IUriService
    {
        #region Attributes
        private readonly string _baseUri;
        #endregion

        #region Constructor
        public UriService(string baseUri)
        {
            _baseUri = baseUri;
        }
        #endregion

        #region Methods
        public Uri GetPropertyUri(PropertyQueryFilter filter, string actionUrl)
        {
            string baseUrl = $"{_baseUri}{actionUrl}";
            return new Uri(baseUrl);
        }
        #endregion
    }
}
