﻿using Microsoft.EntityFrameworkCore;
using Property.Core.Entities;
using System.Reflection;

namespace Property.Infrastructure.Data
{
    /// <summary>
    /// MAnagement DBContext to project Property
    /// </summary>
    public partial class PropertyContext : DbContext
    {
        #region Constructor
        public PropertyContext()
        {
        }

        public PropertyContext(DbContextOptions<PropertyContext> options)
            : base(options)
        {
        }
        #endregion

        #region Attributes
        /// <summary>
        /// Owners
        /// </summary>
        public virtual DbSet<Owner> Owners { get; set; }
        /// <summary>
        /// Properties
        /// </summary>
        public virtual DbSet<Property.Core.Entities.Property> Properties { get; set; }
        /// <summary>
        /// Property Images
        /// </summary>
        public virtual DbSet<PropertyImage> PropertyImages { get; set; }
        /// <summary>
        /// Property Traces
        /// </summary>
        public virtual DbSet<PropertyTrace> PropertyTraces { get; set; }
        #endregion

        #region Methods
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
        #endregion
    }
}
