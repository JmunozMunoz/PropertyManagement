﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Property.Infrastructure.Data.Configurations
{
    /// <summary>
    /// Configuration Entity Property
    /// </summary>
    public class PropertyConfiguration : IEntityTypeConfiguration<Property.Core.Entities.Property>
    {
        public void Configure(EntityTypeBuilder<Core.Entities.Property> builder)
        {
            builder.ToTable("Property");

            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnName("IdProperty");

            builder.Property(e => e.Address)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            builder.Property(e => e.CodeInternal)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);

            builder.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            builder.HasOne(d => d.IdOwnerNavigation)
                .WithMany(p => p.Properties)
                .HasForeignKey(d => d.IdOwner)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Property_Property");
        }
    }
}
