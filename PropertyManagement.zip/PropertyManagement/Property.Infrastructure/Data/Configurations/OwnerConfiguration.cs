﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Property.Core.Entities;

namespace Property.Infrastructure.Data.Configurations
{
    /// <summary>
    /// Configuration Entity Owner
    /// </summary>
    public class OwnerConfiguration : IEntityTypeConfiguration<Owner>
    {
        public void Configure(EntityTypeBuilder<Owner> builder)
        {
            builder.ToTable("Owner"); 
            
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnName("IdOwner");

            builder.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

            builder.Property(e => e.Birthday)
                    .HasColumnType("datetime")
                    .HasColumnName("birthday");

            builder.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

            builder.Property(e => e.Photo)
                    .IsRequired()
                    .HasColumnType("image");
        }
    }
}
