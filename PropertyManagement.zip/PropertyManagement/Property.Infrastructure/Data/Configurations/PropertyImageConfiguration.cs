﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Property.Core.Entities;

namespace Property.Infrastructure.Data.Configurations
{
    /// <summary>
    /// Configuration Entity Property Image
    /// </summary>
    public class PropertyImageConfiguration : IEntityTypeConfiguration<PropertyImage>
    {
        public void Configure(EntityTypeBuilder<PropertyImage> builder)
        {
            builder.ToTable("PropertyImage");

            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnName("IdPropertyImage");

            builder.Property(e => e.File)
                .IsRequired()
                .HasColumnType("image");

            builder.HasOne(d => d.IdPropertyNavigation)
                .WithMany(p => p.PropertyImages)
                .HasForeignKey(d => d.IdProperty)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PropertyImage_PropertyImage");
        }
    }
}
