﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Property.Core.Entities;

namespace Property.Infrastructure.Data.Configurations
{
    /// <summary>
    /// Configuration Entity Property Trace
    /// </summary>
    public class PropertyTraceConfiguration : IEntityTypeConfiguration<PropertyTrace>
    {
        public void Configure(EntityTypeBuilder<PropertyTrace> builder)
        {
            builder.ToTable("PropertyTrace");
            
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnName("IdPropertyTrace");

            builder.Property(e => e.DateSale).HasColumnType("datetime");

            builder.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            builder.Property(e => e.Tax).HasColumnType("decimal(16, 2)");

            builder.HasOne(d => d.IdPropertyNavigation)
                .WithMany(p => p.PropertyTraces)
                .HasForeignKey(d => d.IdProperty)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_PropertyTrace_Property");
        }
    }
}
