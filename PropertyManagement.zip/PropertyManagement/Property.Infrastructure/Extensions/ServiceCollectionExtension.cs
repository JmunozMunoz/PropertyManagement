﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using Property.Core.Interfaces;
using Property.Core.Services;
using Property.Infrastructure.Data;
using Property.Infrastructure.Interfaces;
using Property.Infrastructure.Options;
using Property.Infrastructure.Repositories;
using Property.Infrastructure.Services;
using System;
using System.IO;

namespace Property.Infrastructure.Extensions
{
    /// <summary>
    /// Management Collections to Service
    /// </summary>
    public static class ServiceCollectionExtension
    {
        /// <summary>
        /// Add DataBase Context
        /// </summary>
        /// <param name="services">Service</param>
        /// <param name="configuration">Configuration</param>
        /// <returns>Collections Service</returns>
        public static IServiceCollection AddDbContexts(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<PropertyContext>(options =>
               options.UseSqlServer(configuration.GetConnectionString("Property"))
           );

            return services;
        }

        /// <summary>
        /// Add Options
        /// </summary>
        /// <param name="services">Service</param>
        /// <param name="configuration">Configuration</param>
        /// <returns>Collections Service</returns>
        public static IServiceCollection AddOptions(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<PasswordOptions>(options => configuration.GetSection("PasswordOptions").Bind(options));

            return services;
        }

        /// <summary>
        /// Add Services
        /// </summary>
        /// <param name="services">Collections Services</param>
        /// <returns>Collections Services</returns>
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddTransient<IPropertyService, PropertyService>();
            services.AddTransient<ISecurityService, SecurityService>();
            services.AddTransient<IPropertyImageService, PropertyImageService>();
            services.AddTransient<IPropertyTraceService, PropertyTraceService>();
            services.AddScoped(typeof(IRepository<>), typeof(BaseRepository<>));
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddSingleton<IPasswordService, PasswordService>();
            services.AddSingleton<IUriService>(provider =>
            {
                var accesor = provider.GetRequiredService<IHttpContextAccessor>();
                var request = accesor.HttpContext.Request;
                var absoluteUri = string.Concat(request.Scheme, "://", request.Host.ToUriComponent());
                return new UriService(absoluteUri);
            });

            return services;
        }

        /// <summary>
        /// Add Swagger Documentation
        /// </summary>
        /// <param name="services">Service</param>
        /// <param name="xmlFileName">FileName</param>
        /// <returns>Collection Services</returns>
        public static IServiceCollection AddSwagger(this IServiceCollection services, string xmlFileName)
        {
            services.AddSwaggerGen(doc =>
            {
                doc.SwaggerDoc("v1", new OpenApiInfo { Title = "Property API", Version = "v1" });

                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFileName);
                doc.IncludeXmlComments(xmlPath);
            });

            return services;
        }
    }
}
