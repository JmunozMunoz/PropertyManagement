﻿using FluentValidation;
using Property.Core.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace Property.Infrastructure.Validators
{
    /// <summary>
    /// Class to Validate Property using FluentValidation
    /// </summary>
    public class PropertyValidator : AbstractValidator<PropertyDto>
    {
        public PropertyValidator()
        {
            RuleFor(property => property.Name)
                .NotNull()
                .WithMessage("El nombre no puede ser nula");

            RuleFor(property => property.Name)
                .Length(1, 100)
                .WithMessage("La longitud del nombre debe estar entre 1 y 100 caracteres");

            RuleFor(property => property.Address)
            .NotNull()
            .WithMessage("La dirección no puede ser nula");

            RuleFor(property => property.Address)
                .Length(1, 100)
                .WithMessage("La longitud de la direccíon debe estar entre 1 y 100 caracteres");

            RuleFor(property => property.CodeInternal)
            .NotNull()
            .WithMessage("El codigo interno no puede ser nula");

            RuleFor(property => property.CodeInternal)
                .Length(1, 10)
                .WithMessage("La longitud del codigo interno debe estar entre 1 y 10 caracteres");

            RuleFor(property => property.Price)
            .NotNull()
            .WithMessage("El Precio no puede ser nula");

            RuleFor(property => property.Year)
            .NotNull()
            .WithMessage("El año no puede ser nulo");

        }
    }
}
