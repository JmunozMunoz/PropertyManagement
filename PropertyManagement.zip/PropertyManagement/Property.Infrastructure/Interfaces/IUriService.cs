﻿using Property.Core.QueryFilters;
using System;

namespace Property.Infrastructure.Interfaces
{
    public interface IUriService
    {
        Uri GetPropertyUri(PropertyQueryFilter filter, string actionUrl);
    }
}