﻿namespace Property.Infrastructure.Interfaces
{
    /// <summary>
    /// Interface Password Services
    /// </summary>
    public interface IPasswordService
    {
        /// <summary>
        /// Get Password Hash
        /// </summary>
        /// <param name="password">Password</param>
        /// <returns>Pasword Hash</returns>
        string Hash(string password);

        /// <summary>
        /// Validate the user and password
        /// </summary>
        /// <param name="hash">User</param>
        /// <param name="password">Password</param>
        /// <returns>Is Check</returns>
        bool Check(string hash, string password);
    }
}
