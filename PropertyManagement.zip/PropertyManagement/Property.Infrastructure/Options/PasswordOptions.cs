﻿namespace Property.Infrastructure.Options
{
    /// <summary>
    /// Options to Password
    /// </summary>
    public class PasswordOptions
    {
        public int SaltSize { get; set; }
        public int KeySize { get; set; }
        public int Iterations { get; set; }
    }
}
